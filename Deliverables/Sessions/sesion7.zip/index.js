// Server 

var http = require('http');

function onServer(request, response) {
    console.log("Petición OK");
    response.writeHead(200, { "Content-Type": "text/html" })

    response.write("<h1>Server online, hellow! </h1>");

    response.end();
}

var server = http.createServer(onServer);

server.listen(3000);

console.log("Working http://localhost:3000/")