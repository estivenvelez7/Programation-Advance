// Service HTML

var countService = 0;
var priceAcumulate = 0;
var averangeSells = 0;

function save(){
    var name = document.getElementById("name").value;
    var description = document.getElementById("description").value;
    var price = parseInt(document.getElementById("price").value);

    if (name != "" && description != "" && price != "") {
        var table = document.getElementById("myTable");
        var rowCount = table.rows.length;
        var row = table.insertRow(rowCount);
        row.insertCell(0).innerHTML = name;
        row.insertCell(1).innerHTML = description;
        row.insertCell(2).innerHTML = "$ " + new Intl.NumberFormat().format(price);
        
        countService++;
        priceAcumulate+= price;
        clean();
        
        averangeSells = parseInt(priceAcumulate / countService);
        document.getElementById("prom").innerHTML = "$ " + new Intl.NumberFormat().format(averangeSells);
        document.getElementById("cant").innerHTML = countService;
    }else{
        alert("Fill all fields.");
    }
}

function clean() {
    document.getElementById("name").value = "";
    document.getElementById("description").value = "";
    document.getElementById("price").value = "";

    document.getElementById("name").focus();
}